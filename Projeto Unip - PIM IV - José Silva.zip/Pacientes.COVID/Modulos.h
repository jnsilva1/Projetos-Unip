#ifndef MODULOS
#define MODULOS
void ImprimirHeaderPadrao();
void CadastrarPaciente();
void ListarPacientes();
void AlterarSenha();
void InformaMenuInvalido();
void GetComandoPadrao();
void ImprimirMenu();
void Inicializar();
#endif // MODULOS
