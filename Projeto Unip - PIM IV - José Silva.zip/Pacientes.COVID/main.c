#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdfix.h>
#include "Modulos.h"
int main(void)
{
    Inicializar();

    return 0;
}
